<?php
    $output = (isset($content) ? $content  : '');
    echo $output . "<br />\n";
?>
